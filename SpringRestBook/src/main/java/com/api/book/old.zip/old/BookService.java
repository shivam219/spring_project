package com.api.book.old;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

@Component
public class BookService {

	private static List<Book> list = new ArrayList<>();

	static {
		list.add(new Book(1, "java", "shivam"));
		list.add(new Book(2, "php", "rama"));
		list.add(new Book(3, "web", "shiva"));
	}

	public ResponseEntity<List<Book>> getAllBooks() {

		if (list.size() == 0) {
//			return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
		}
		return ResponseEntity.of(Optional.of(list));
	}

	public ResponseEntity<Object> getBook(int id2) {

//		return	new ResponseEntity<>("Product is deleted successsfully", HttpStatus.OK);
		try {
			Book book = list.stream().filter(e -> e.id == id2).findFirst().get();
//			ResponseEntity.status(HttpStatus.NOT_FOUND).build();
			return ResponseEntity.of(Optional.of(book));
		} catch (Exception e) {
			return new ResponseEntity<>("Product is not available successsfully", HttpStatus.NOT_FOUND);
		}
	}

	public Book addBook(Book b) {
		list.add(b);
		return b;
	}

	//delete book by id
//	public List<Book> deleteBook(int idd) {
//		list = list.stream().filter(e -> e.id != idd).collect(Collectors.toList());
//		return list;
//	}
	public ResponseEntity<Void> deleteBook(int id) {
		try {		
			list.remove(id);
			return  ResponseEntity.status(HttpStatus.NO_CONTENT).build();
		} catch (Exception e) {
			return  ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
		
	}

	public List<Book> updataBook(Book book, int idd) {
		return list.stream().map(e -> {
			if (e.id == idd) {
				e.setTitle(book.getTitle());
				e.setAuthor(book.getAuthor());
			}
			return e;
		}).collect(Collectors.toList());
	}

	
}
