package com.timesheet.model;

//@Entity
public class UserPositionView {

}
